DO NOT FORWARD THIS FOLDER
==========================

agent/keystore.jks is the release signing key for the Break Remote Android app.

  alias      agent-release
  passwords  Br34kR3mote!demo   (store and key)
  algorithm  RSA 4096, valid 30 years

Whoever holds this key can ship an update to any phone that has the app
installed. Treat it like a production credential.

Why it is in this package
-------------------------
So the recipient can produce a signed APK locally without waiting for CI. It is
NOT required for that -- CI signs every release from the KEYSTORE_BASE64 Actions
secret. If you would rather not have it, re-run the packaging script with
--no-secrets, or delete this folder.

Rules
-----
1. Never rotate or regenerate it. A new key is a different signing identity.
   Android refuses to install an update signed with a different key, so the
   phone owner would have to uninstall first, losing all enrolment settings and
   forcing the whole setup again.
2. Back it up privately and durably. It cannot be regenerated from GitHub.
3. Do not commit it, and do not send it onward.

To use it locally
-----------------
Create agent/keystore.properties (gitignored, and NOT included here because it
holds a machine-specific absolute path):

    KEYSTORE_PATH=<absolute path to agent/keystore.jks>
    KEYSTORE_PASSWORD=Br34kR3mote!demo
    KEY_ALIAS=agent-release
    KEY_PASSWORD=Br34kR3mote!demo

Then:  cd agent && gradlew.bat assembleRelease
